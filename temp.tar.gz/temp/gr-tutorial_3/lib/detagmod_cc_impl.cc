/* -*- c++ -*- */
/*
 * Copyright 2022 gr-tutorial_3 author.
 *
 * This is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3, or (at your option)
 * any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this software; see the file COPYING.  If not, write to
 * the Free Software Foundation, Inc., 51 Franklin Street,
 * Boston, MA 02110-1301, USA.
 */

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#include <gnuradio/io_signature.h>
#include "detagmod_cc_impl.h"

namespace gr {
  namespace tutorial_3 {

    detagmod_cc::sptr
    detagmod_cc::make()
    {
      return gnuradio::get_initial_sptr
        (new detagmod_cc_impl());
    }


    /*
     * The private constructor
     */
    detagmod_cc_impl::detagmod_cc_impl()
      : gr::sync_block("detagmod_cc",
              gr::io_signature::make(1, 1, sizeof(gr_complex)),
              gr::io_signature::make(1, 1, sizeof(gr_complex)))
    {}

    /*
     * Our virtual destructor.
     */
    detagmod_cc_impl::~detagmod_cc_impl()
    {
    }
    void
    detagmod_cc_impl::forecast (int noutput_items, gr_vector_int &ninput_items_required)
    {
        ninput_items_required[0] = noutput_items;
    }

    int
    detagmod_cc_impl::work(int noutput_items,
        gr_vector_const_void_star &input_items,
        gr_vector_void_star &output_items)
    {
      const gr_complex *in = (const gr_complex *) input_items[0];
      gr_complex *out0 = (gr_complex *) output_items[0];
      int len=int(noutput_items/432);
      //int temp=0
      for(int ii=0;ii<len;ii++)
      {
      	for(int tt=384*ii;tt<384*(ii+1);tt++)
      	{
      		out0[tt]=in[tt+48*(ii+1)];
      	}
      	//temp++;
      }
      int cl=noutput_items-len*432;
      if(cl>48)
      {
      	for (int cc=0;cc<cl-48;cc++)
      	{
      		out0[384*len+cc]=in[432*len+48+cc];
      	}
      }
      //gr_complex *out1 = (gr_complex *) output_items[1];
      //memcpy(out0, in,sizeof(gr_complex)*noutput_items);
      // Do <+signal processing+>

      // Tell runtime system how many output items we produced.
      return noutput_items;
    }

  } /* namespace tutorial_3 */
} /* namespace gr */

