/* -*- c++ -*- */
/*
 * Copyright 2022 gr-tutorial_1 author.
 *
 * This is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3, or (at your option)
 * any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this software; see the file COPYING.  If not, write to
 * the Free Software Foundation, Inc., 51 Franklin Street,
 * Boston, MA 02110-1301, USA.
 */

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#include <gnuradio/io_signature.h>
#include "alamouti_mods_cc_impl.h"

namespace gr {
  namespace tutorial_1 {

    alamouti_mods_cc::sptr
    alamouti_mods_cc::make()
    {
      return gnuradio::get_initial_sptr
        (new alamouti_mods_cc_impl());
    }


    /*
     * The private constructor
     */
    alamouti_mods_cc_impl::alamouti_mods_cc_impl()
      : gr::sync_block("alamouti_mods_cc",
               gr::io_signature::make(1, 1, sizeof(gr_complex)),
              gr::io_signature::make(1, 1, sizeof(gr_complex)))
             // d_vlen(vlen)
    {
    	const int alignment_multiple = volk_get_alignment() / sizeof(gr_complex);
    	set_alignment(std::max(1, alignment_multiple));
    }

    /*
     * Our virtual destructor.
     */
    alamouti_mods_cc_impl::~alamouti_mods_cc_impl()
    {
    }
    void
    alamouti_mods_cc_impl::forecast (int noutput_items, gr_vector_int &ninput_items_required)
    {
        ninput_items_required[0] = noutput_items;
    }
    int
    alamouti_mods_cc_impl::work(int noutput_items,
        gr_vector_const_void_star &input_items,
        gr_vector_void_star &output_items)
    {
    const gr_complex *in = (const gr_complex *) input_items[0];
      gr_complex *out0 = (gr_complex *) output_items[0];
      //gr_complex *out1 = (gr_complex *) output_items[1];
      memcpy(out0, in,sizeof(gr_complex)*noutput_items);
    //  memcpy(out1, in,sizeof(gr_complex)*noutput_items);
      //for (int ii = 0; ii < noutput_items; ii+=2) {
       // out0[ii] = in[ii];
   	// }
    	//for (int ii = 1; ii < noutput_items; ii+=2) {
        //	out0[ii] = conj(in[ii]);
   	 //}
   	for (int ii = 0; ii < noutput_items-1; ii+=2) {
        	out0[ii] = in[ii+1];
   	 }
    	for (int ii = 1; ii < noutput_items; ii+=2) {
        	out0[ii] = -conj(in[ii-1]);
   	 }
   	//consume_each(noutput_items);
      return noutput_items;
    }

  } /* namespace tutorial_1 */
} /* namespace gr */

