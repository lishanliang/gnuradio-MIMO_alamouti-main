/* -*- c++ -*- */
/*
 * Copyright 2022 gr-tutorial_2 author.
 *
 * This is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3, or (at your option)
 * any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this software; see the file COPYING.  If not, write to
 * the Free Software Foundation, Inc., 51 Franklin Street,
 * Boston, MA 02110-1301, USA.
 */

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#include <gnuradio/io_signature.h>
#include "estimation_mod_cc_impl.h"

namespace gr {
  namespace tutorial_2 {

    estimation_mod_cc::sptr
    estimation_mod_cc::make()
    {
      return gnuradio::get_initial_sptr
        (new estimation_mod_cc_impl());
    }


    /*
     * The private constructor
     */
    estimation_mod_cc_impl::estimation_mod_cc_impl()
      : gr::sync_block("estimation_mod_cc",
             gr::io_signature::make(2, 2, sizeof(gr_complex)),
             gr::io_signature::make(2, 2, sizeof(gr_complex)))
    {
    	//
    	const int alignment_multiple = volk_get_alignment() / sizeof(gr_complex);
    	set_alignment(std::max(1, alignment_multiple));
    }

    /*
     * Our virtual destructor.
     */
    estimation_mod_cc_impl::~estimation_mod_cc_impl()
    {
    }
    void
    estimation_mod_cc_impl::forecast (int noutput_items, gr_vector_int &ninput_items_required)
    {
       unsigned ninputs = ninput_items_required.size();  // 获取输入端口的数量
      for (unsigned i = 0; i < ninputs; i++)
      {
        ninput_items_required[i] = noutput_items;  // 输入数据量等于输出数据量
      }

    }

    int
    estimation_mod_cc_impl::work(int noutput_items,
        gr_vector_const_void_star &input_items,
        gr_vector_void_star &output_items)
    {
      const gr_complex *in1 = (const gr_complex *) input_items[0];
      const gr_complex *in2 = (const gr_complex *) input_items[1];
      gr_complex *out1 = (gr_complex *) output_items[0];
      gr_complex *out2 = (gr_complex *) output_items[1];
      memcpy(out1, in1,sizeof(gr_complex)*noutput_items);
      memcpy(out2, in2,sizeof(gr_complex)*noutput_items);
      int cp_len=noutput_items-48;
      //rintf("%d,%5d\n",20,432);
      std::vector<gr_complex> tag1(12,gr_complex(0, 0));
      std::vector<gr_complex> tag2(12,gr_complex(0, 0));
      std::vector<gr_complex> tmp1(cp_len,gr_complex(0, 0));
      std::vector<gr_complex> tmp2(cp_len,gr_complex(0, 0));

      
      //memcpy(tmp2, in2,sizeof(gr_complex)*cp_len);
     // memcpy(tmp1, in1,sizeof(gr_complex)*cp_len);
      //memcpy(tag2, in2,sizeof(gr_complex)*12);
      //memcpy(tag1, in1,sizeof(gr_complex)*12);//取前12位
     // memcpy(out2, in2,sizeof(gr_complex)*noutput_items);
      //memcpy(out1, in1,sizeof(gr_complex)*noutput_items);
      for (int ii = 0; ii < 12; ii++) {
        tag1[ii] = in1[ii];
        tag2[ii] = in2[ii];
   	 }
      for (int ii = 48; ii < 432; ii++) {
        tmp1[ii-48] = in1[ii];
        tmp2[ii-48] = in2[ii];
   	 }
     //创建二维数组P;Yp;并进行初始化
     std::vector<std::vector<gr_complex>> preY(2,std::vector<gr_complex>(noutput_items,gr_complex(0, 0)));
     std::vector<gr_complex> Yp0(12,gr_complex(0, 0));
     std::vector<gr_complex> Yp1(12,gr_complex(0, 0));
     std::vector<gr_complex> preY0(noutput_items,gr_complex(0, 0));
     std::vector<gr_complex> preY1(noutput_items,gr_complex(0, 0));
     std::vector<std::vector<gr_complex>> Yp(2,std::vector<gr_complex>(12,gr_complex(0, 0)));
     for (int ii = 0; ii < noutput_items; ii++) {
        	preY[0][ii] = in1[ii];
        	preY[1][ii]=in2[ii];
   	}
     for (int ii = 0; ii < 12; ii++) {
        	//Yp0[ii] = in1[ii];
        	//Yp1[ii]=in2[ii];
        	Yp[0][ii] = in1[ii];
        	Yp[1][ii]=in2[ii];
   	}     
   
   //利用P和Yp求信道参数H(2,2) =Yp*P_H(P*P_H)_1；
   /*P_H(P*P_H)_1=
   -0.0833   -0.0833
   -0.0833    0.0833
   
   -0.0833   -0.0833
   -0.0833    0.0833
   
   -0.0833    0.0833
    0.0833    0.0833
    
    0.0833   -0.0833
   -0.0833   -0.0833
   
   -0.0833   -0.0833
   -0.0833    0.0833
   
   -0.0833   -0.0833
   -0.0833    0.0833
   */
   
  std::vector<std::vector<gr_complex>> pH={{-0.0833,-0.0833},{-0.0833,0.0833},{-0.0833,-0.0833},{-0.0833,0.0833},{-0.0833,0.0833},{0.0833,0.0833},{0.0833,-0.0833},{-0.0833,-0.0833},{-0.0833,-0.0833},{-0.0833,0.0833},{-0.0833,-0.0833},{-0.0833,0.0833}};
   std::vector<std::vector<gr_complex>> H(2,std::vector<gr_complex>(2,gr_complex(0, 0)));//H为2*2矩阵；
   std::vector<std::vector<gr_complex>> H_1(2,std::vector<gr_complex>(2,gr_complex(0, 0)));//H_1为2*2矩阵；H的逆矩阵；
   H=multi(Yp,pH);
   double cc=(H[0][0].real()*H[1][1].real()-H[1][0].real()*H[0][1].real());
   if(cc<0.0001&&cc>-0.001)cc=1;
   //double cc=1;
   H_1[0][0]=(1/cc)*H[1][1].real();
   H_1[0][1]=-(1/cc)*H[1][0].real();
   H_1[1][0]=-(1/cc)*H[0][1].real();
   H_1[1][1]=(1/cc)*H[0][0].real();//矩阵求ni
   //计算估计值
   std::vector<std::vector<gr_complex>> estiX(2,std::vector<gr_complex>(noutput_items,gr_complex(0, 0)));
   estiX=multi(H_1,preY);
   /*for(int ii=0;ii<48;ii++){
   out1[ii]=in1[ii];
   out2[ii]=in2[ii];
   }*/
   for(int ii=0;ii<noutput_items;ii++){
     out1[ii]=estiX[0][ii];
     out2[ii]=estiX[1][ii];
   }
   
    
    //test
   /*for (int ii = 0; ii < noutput_items; ii++) {
        	out1[ii] = in1[ii];
   	 }
   for (int ii = 1; ii < noutput_items; ii++) {
        	out2[ii] = -conj(in2[ii]);
   	 }*/
   return noutput_items;
   }
std::vector<std::vector<gr_complex >> estimation_mod_cc_impl::trans(std::vector<std::vector<gr_complex>>&aa){//转置
        int rowa=aa.size();
        int cola=aa[0].size();
        std::vector<std::vector<gr_complex>> tmp;
      	for(int ii=0;ii<rowa;ii++){
      		for(int jj=0;jj<cola;jj++)
      			tmp[jj][ii]=aa[ii][jj];
      	}
      	for(int ii=0;ii<cola;ii++){
      		for(int jj=0;jj<rowa;jj++)
      			tmp[ii][jj]=conj(tmp[ii][jj]);
      	}
      	return tmp;
      }    
std::vector<std::vector<gr_complex>> estimation_mod_cc_impl::multi(std::vector<std::vector<gr_complex>>&aa,std::vector<std::vector<gr_complex>>&bb){//矩阵相乘
        int rowa=aa.size();
        int cola=aa[0].size();
        int rowb=bb.size();
        int colb=bb[0].size();
        std::vector<std::vector<gr_complex>> res(rowa,std::vector<gr_complex>(colb,gr_complex(0, 0)));
        if(cola!=rowb){return res;}
        else
        {
        	res.resize(rowa);
        	for(int i=0;i<rowa;++i){
        		res[i].resize(colb);
        	}
        	for(int i=0;i<rowa;++i){
        		for(int j=0;j<colb;++j){
        			for(int k=0;k<cola;++k){
        				res[i][j]+=aa[i][k]*bb[k][j];
        			}
        		}
        	}
        }
        return res;
        	        
       };
  } /* namespace tutorial_2 */
} /* namespace gr */

