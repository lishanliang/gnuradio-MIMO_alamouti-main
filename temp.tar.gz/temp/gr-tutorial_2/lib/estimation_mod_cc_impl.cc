/* -*- c++ -*- */
/*
 * Copyright 2022 gr-tutorial_2 author.
 *
 * This is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3, or (at your option)
 * any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this software; see the file COPYING.  If not, write to
 * the Free Software Foundation, Inc., 51 Franklin Street,
 * Boston, MA 02110-1301, USA.
 */

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#include <gnuradio/io_signature.h>
#include "estimation_mod_cc_impl.h"

namespace gr {
  namespace tutorial_2 {

    estimation_mod_cc::sptr
    estimation_mod_cc::make()
    {
      return gnuradio::get_initial_sptr
        (new estimation_mod_cc_impl());
    }


    /*
     * The private constructor
     */
    estimation_mod_cc_impl::estimation_mod_cc_impl()
      : gr::sync_block("estimation_mod_cc",
             gr::io_signature::make(2, 2, sizeof(gr_complex)),
             gr::io_signature::make(2, 2, sizeof(gr_complex)))
    {
    	//
    	const int alignment_multiple = volk_get_alignment() / sizeof(gr_complex);
    	set_alignment(std::max(1, alignment_multiple));
    }

    /*
     * Our virtual destructor.
     */
    estimation_mod_cc_impl::~estimation_mod_cc_impl()
    {
    }
    void
    estimation_mod_cc_impl::forecast (int noutput_items, gr_vector_int &ninput_items_required)
    {
       unsigned ninputs = ninput_items_required.size();  // 获取输入端口的数量
      for (unsigned i = 0; i < ninputs; i++)
      {
        ninput_items_required[i] = noutput_items;  // 输入数据量等于输出数据量
      }

    }

    int
    estimation_mod_cc_impl::work(int noutput_items,
        gr_vector_const_void_star &input_items,
        gr_vector_void_star &output_items)
    {
      const gr_complex *in1 = (const gr_complex *) input_items[0];
      const gr_complex *in2 = (const gr_complex *) input_items[1];
      gr_complex *out1 = (gr_complex *) output_items[0];
      gr_complex *out2 = (gr_complex *) output_items[1];
      memcpy(out1, in1,sizeof(gr_complex)*noutput_items);
      memcpy(out2, in2,sizeof(gr_complex)*noutput_items);
      if (noutput_items <48)return noutput_items;
      int cp_len=noutput_items-48;
      //rintf("%d,%5d\n",20,432);
      std::vector<gr_complex> s_11(noutput_items,gr_complex(0, 0));//s11,s12
      std::vector<gr_complex> s_22(noutput_items,gr_complex(0, 0));
     // memcpy(out2, in2,sizeof(gr_complex)*noutput_items);
      //memcpy(out1, in1,sizeof(gr_complex)*noutput_items);
     //创建二维数组PreY;Yp;并进行初始化
     std::vector<std::vector<gr_complex>> preY(2,std::vector<gr_complex>(noutput_items,gr_complex(0, 0)));
     std::vector<std::vector<gr_complex>> Yp(2,std::vector<gr_complex>(12,gr_complex(0, 0)));
     for (int ii = 0; ii < noutput_items; ii++) {
        	preY[0][ii] = in1[ii];
        	preY[1][ii]=in2[ii];
   	}
     for (int ii = 0; ii < 12; ii++) {
        	Yp[0][ii] = in1[ii];
        	Yp[1][ii]=in2[ii];
   	}     
   
   //利用P和Yp求信道参数H(2,2) =Yp*P_H(P*P_H)_1；
   /*P_H(P*P_H)_1=
   -0.0833   -0.0833
   -0.0833    0.0833
   
   -0.0833   -0.0833
   -0.0833    0.0833
   
   -0.0833    0.0833
    0.0833    0.0833
    
    0.0833   -0.0833
   -0.0833   -0.0833
   
   -0.0833   -0.0833
   -0.0833    0.0833
   
   -0.0833   -0.0833
   -0.0833    0.0833
   */
   
  std::vector<std::vector<gr_complex>> pH={{-0.0833,-0.0833},{-0.0833,0.0833},{-0.0833,-0.0833},{-0.0833,0.0833},{-0.0833,0.0833},{0.0833,0.0833},{0.0833,-0.0833},{-0.0833,-0.0833},{-0.0833,-0.0833},{-0.0833,0.0833},{-0.0833,-0.0833},{-0.0833,0.0833}};
   std::vector<std::vector<gr_complex>> H(2,std::vector<gr_complex>(2,gr_complex(0, 0)));//H为2*2矩阵；
   H=multi(Yp,pH);
   for (int i = 0; i < noutput_items-1; i+=2) 
   {
       s_11[i]=H[0][0].real()*in1[i]-H[0][1].real()*conj(in1[i+1]);
       s_22[i]=H[1][0].real()*in2[i]-H[1][1].real()*conj(in2[i+1]);
   }
   for (int i = 1; i < noutput_items; i+=2)
   {
        s_11[i]=H[0][1].real()*in1[i-1]+H[0][0].real()*conj(in1[i]);
        s_22[i]=H[1][1].real()*in2[i-1]+H[1][0].real()*conj(in2[i]);
   }   
   float c1=pow(H[0][0].real(),2)+pow(H[0][1].real(),2);
   float c2=pow(H[1][0].real(),2)+pow(H[1][1].real(),2);
   for(int ii=0;ii<noutput_items-1;ii++)
   {
   	out1[ii]=c1*s_11[ii]+c2*s_22[ii];
   	//out1[ii]=s_22[ii];
   }
   for(int ii=0;ii<noutput_items-1;ii++){
     //out1[ii]=estiX[0][ii];
     out2[ii]=s_22[ii];
   }
   return noutput_items;
   }
std::vector<std::vector<gr_complex >> estimation_mod_cc_impl::trans(std::vector<std::vector<gr_complex>>&aa){//转置
        int rowa=aa.size();
        int cola=aa[0].size();
        std::vector<std::vector<gr_complex>> tmp;
      	for(int ii=0;ii<rowa;ii++){
      		for(int jj=0;jj<cola;jj++)
      			tmp[jj][ii]=aa[ii][jj];
      	}
      	for(int ii=0;ii<cola;ii++){
      		for(int jj=0;jj<rowa;jj++)
      			tmp[ii][jj]=conj(tmp[ii][jj]);
      	}
      	return tmp;
      }    
std::vector<std::vector<gr_complex>> estimation_mod_cc_impl::multi(std::vector<std::vector<gr_complex>>&aa,std::vector<std::vector<gr_complex>>&bb){//矩阵相乘
        int rowa=aa.size();
        int cola=aa[0].size();
        int rowb=bb.size();
        int colb=bb[0].size();
        std::vector<std::vector<gr_complex>> res(rowa,std::vector<gr_complex>(colb,gr_complex(0, 0)));
        if(cola!=rowb){return res;}
        else
        {
        	res.resize(rowa);
        	for(int i=0;i<rowa;++i){
        		res[i].resize(colb);
        	}
        	for(int i=0;i<rowa;++i){
        		for(int j=0;j<colb;++j){
        			for(int k=0;k<cola;++k){
        				res[i][j]+=aa[i][k]*bb[k][j];
        			}
        		}
        	}
        }
        return res;
        	        
       };
  } /* namespace tutorial_2 */
} /* namespace gr */

